<?php defined('SYSPATH') or die('No direct script access.');

abstract class Controller extends Kohana_Controller {}
