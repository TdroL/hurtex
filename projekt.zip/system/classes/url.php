<?php defined('SYSPATH') or die('No direct script access.');

class URL extends Kohana_URL {}