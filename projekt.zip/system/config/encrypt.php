<?php defined('SYSPATH') or die('No direct script access.');

return array(

	'default' => array(
		'key'    => 'change this encryption key',
		'mode'   => MCRYPT_MODE_NOFB,
		'cipher' => MCRYPT_RIJNDAEL_128
	),

);
