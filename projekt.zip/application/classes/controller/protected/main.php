<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Protected_Main extends Controller_Auth
{
	public function action_index()
	{
	
	}
}
