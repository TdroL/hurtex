<?php defined('SYSPATH') OR die('No direct access allowed.') ?>
<!DOCTYPE html>
<html lang="pl">
<head>
	<title>Projekt zespołowy</title>
	<meta charset="UTF-8" />
	<?php echo html::style('media/style.css') ?>
</head>
<body>
	<h1>Projekt zespołowy</h1>
	<div id="container">
		<?php echo $content ?>
	</div>
</body>
</html>