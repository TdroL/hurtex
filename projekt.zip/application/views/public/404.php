<h1><?php echo __('Error') ?></h1>
<h3><?php echo utf8::ucfirst($message) ?></h3>