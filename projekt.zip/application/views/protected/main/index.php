<?php defined('SYSPATH') or die('No direct script access.'); ?>

<p>Plik wygl�du admin/main/index</p>