<!DOCTYPE html>
<html lang="pl">
<head>
	<title>Projekt zespo�owy - administracja</title>
	<meta charset="UTF-8" />
	<?php echo html::style('media/admin/style.css') ?>
</head>
<body>
	<p>Plik wygl�du admin/main/login</p>
</body>
</html>



