<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-03-13 13:21:30 --- Exception: exception 'ReflectionException' with message 'Class controller_public_main does not exist' in D:\httpd\projekt\system\classes\kohana\request.php:848
Stack trace:
#0 D:\httpd\projekt\system\classes\kohana\request.php(848): ReflectionClass->__construct('controller_publ...')
#1 D:\httpd\projekt\application\bootstrap.php(178): Kohana_Request->execute()
#2 D:\httpd\projekt\index.php(106): require('D:\httpd\projek...')
#3 {main}
2010-03-13 13:21:30 --- ERROR: ReflectionException [ -1 ]: Class controller_public_main does not exist ~ SYSPATH/classes\kohana\request.php [ 848 ]
2010-03-13 13:31:00 --- 500: exception 'ReflectionException' with message 'Class controller_public_projekt does not exist' in D:\httpd\projekt\system\classes\kohana\request.php:848
Stack trace:
#0 D:\httpd\projekt\system\classes\kohana\request.php(848): ReflectionClass->__construct('controller_publ...')
#1 D:\httpd\projekt\application\bootstrap.php(152): Kohana_Request->execute()
#2 D:\httpd\projekt\index.php(106): require('D:\httpd\projek...')
#3 {main}
URI: projekt
2010-03-13 13:31:27 --- 500: exception 'ReflectionException' with message 'Class controller_public_projekt does not exist' in D:\httpd\projekt\system\classes\kohana\request.php:848
Stack trace:
#0 D:\httpd\projekt\system\classes\kohana\request.php(848): ReflectionClass->__construct('controller_publ...')
#1 D:\httpd\projekt\application\bootstrap.php(152): Kohana_Request->execute()
#2 D:\httpd\projekt\index.php(106): require('D:\httpd\projek...')
#3 {main}
URI: projekt
2010-03-13 13:31:30 --- 500: exception 'ReflectionException' with message 'Class controller_public_projekt does not exist' in D:\httpd\projekt\system\classes\kohana\request.php:848
Stack trace:
#0 D:\httpd\projekt\system\classes\kohana\request.php(848): ReflectionClass->__construct('controller_publ...')
#1 D:\httpd\projekt\application\bootstrap.php(152): Kohana_Request->execute()
#2 D:\httpd\projekt\index.php(106): require('D:\httpd\projek...')
#3 {main}
URI: projekt
2010-03-13 13:32:09 --- 500: exception 'ReflectionException' with message 'Class controller_public_projekt does not exist' in D:\httpd\projekt\system\classes\kohana\request.php:848
Stack trace:
#0 D:\httpd\projekt\system\classes\kohana\request.php(848): ReflectionClass->__construct('controller_publ...')
#1 D:\httpd\projekt\application\bootstrap.php(152): Kohana_Request->execute()
#2 D:\httpd\projekt\index.php(106): require('D:\httpd\projek...')
#3 {main}
URI: projekt
2010-03-13 13:32:10 --- 500: exception 'ReflectionException' with message 'Class controller_public_projekt does not exist' in D:\httpd\projekt\system\classes\kohana\request.php:848
Stack trace:
#0 D:\httpd\projekt\system\classes\kohana\request.php(848): ReflectionClass->__construct('controller_publ...')
#1 D:\httpd\projekt\application\bootstrap.php(152): Kohana_Request->execute()
#2 D:\httpd\projekt\index.php(106): require('D:\httpd\projek...')
#3 {main}
URI: projekt
2010-03-13 13:32:16 --- 500: exception 'ReflectionException' with message 'Class controller_public_projekt does not exist' in D:\httpd\projekt\system\classes\kohana\request.php:848
Stack trace:
#0 D:\httpd\projekt\system\classes\kohana\request.php(848): ReflectionClass->__construct('controller_publ...')
#1 D:\httpd\projekt\application\bootstrap.php(152): Kohana_Request->execute()
#2 D:\httpd\projekt\index.php(106): require('D:\httpd\projek...')
#3 {main}
URI: projekt
2010-03-13 17:30:09 --- 500: exception 'ErrorException' with message 'mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Unknown MySQL server host '***' (11001)' in D:\httpd\projekt\modules\database\classes\kohana\database\mysql.php:49
Stack trace:
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_connect()...', 'D:\httpd\projek...', 49, Array)
#1 D:\httpd\projekt\modules\database\classes\kohana\database\mysql.php(49): mysql_connect('***', '***', '***', true)
#2 D:\httpd\projekt\modules\database\classes\kohana\database\mysql.php(128): Kohana_Database_MySQL->connect()
#3 D:\httpd\projekt\modules\firephp\classes\database\mysql.php(6): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#4 D:\httpd\projekt\modules\database\classes\kohana\database\mysql.php(259): Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#5 D:\httpd\projekt\modules\orm\classes\kohana\orm.php(1131): Kohana_Database_MySQL->list_columns('tests')
#6 D:\httpd\projekt\modules\orm\classes\kohana\orm.php(1030): Kohana_ORM->list_columns(true)
#7 D:\httpd\projekt\modules\orm\classes\kohana\orm.php(512): Kohana_ORM->reload_columns()
#8 D:\httpd\projekt\modules\orm\classes\kohana\orm.php(143): Kohana_ORM->_initialize()
#9 D:\httpd\projekt\modules\orm\classes\kohana\orm.php(115): Kohana_ORM->__construct(NULL)
#10 D:\httpd\projekt\application\base.php(6): Kohana_ORM::factory('Test', NULL)
#11 D:\httpd\projekt\application\classes\controller\public\main.php(7): ORM('Test')
#12 [internal function]: Controller_Public_Main->action_index(NULL)
#13 D:\httpd\projekt\system\classes\kohana\request.php(866): ReflectionMethod->invokeArgs(Object(Controller_Public_Main), Array)
#14 D:\httpd\projekt\application\bootstrap.php(152): Kohana_Request->execute()
#15 D:\httpd\projekt\index.php(106): require('D:\httpd\projek...')
#16 {main}
URI: 
2010-03-13 17:30:12 --- 500: exception 'ErrorException' with message 'mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Unknown MySQL server host '***' (11001)' in D:\httpd\projekt\modules\database\classes\kohana\database\mysql.php:49
Stack trace:
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_connect()...', 'D:\httpd\projek...', 49, Array)
#1 D:\httpd\projekt\modules\database\classes\kohana\database\mysql.php(49): mysql_connect('***', '***', '***', true)
#2 D:\httpd\projekt\modules\database\classes\kohana\database\mysql.php(128): Kohana_Database_MySQL->connect()
#3 D:\httpd\projekt\modules\firephp\classes\database\mysql.php(6): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#4 D:\httpd\projekt\modules\database\classes\kohana\database\mysql.php(259): Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#5 D:\httpd\projekt\modules\orm\classes\kohana\orm.php(1131): Kohana_Database_MySQL->list_columns('tests')
#6 D:\httpd\projekt\modules\orm\classes\kohana\orm.php(1030): Kohana_ORM->list_columns(true)
#7 D:\httpd\projekt\modules\orm\classes\kohana\orm.php(512): Kohana_ORM->reload_columns()
#8 D:\httpd\projekt\modules\orm\classes\kohana\orm.php(143): Kohana_ORM->_initialize()
#9 D:\httpd\projekt\modules\orm\classes\kohana\orm.php(115): Kohana_ORM->__construct(NULL)
#10 D:\httpd\projekt\application\base.php(6): Kohana_ORM::factory('Test', NULL)
#11 D:\httpd\projekt\application\classes\controller\public\main.php(7): ORM('Test')
#12 [internal function]: Controller_Public_Main->action_index(NULL)
#13 D:\httpd\projekt\system\classes\kohana\request.php(866): ReflectionMethod->invokeArgs(Object(Controller_Public_Main), Array)
#14 D:\httpd\projekt\application\bootstrap.php(152): Kohana_Request->execute()
#15 D:\httpd\projekt\index.php(106): require('D:\httpd\projek...')
#16 {main}
URI: 