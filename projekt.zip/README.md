Projekt zespołowy Hurtex!
-----------------------------
(taa, wiemy, że to głupia nazwa :P)

Członkowie:

- _TdroL
- amos001
- kamilklw
- arczi 
- mks911


macha Ci robot \..[-.-]../