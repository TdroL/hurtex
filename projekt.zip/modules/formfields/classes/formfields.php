<?php defined('SYSPATH') or die('No direct script access.');

class FormFields extends Kohana_FormFields {}