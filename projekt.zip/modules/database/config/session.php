<?php defined('SYSPATH') or die('No direct script access.');

return array(
	'database' => array(
		'group' => 'default',
		'table' => 'sessions',
	),
);