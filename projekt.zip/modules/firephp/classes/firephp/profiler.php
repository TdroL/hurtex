<?php defined('SYSPATH') or die('No direct script access.');

class FirePHP_Profiler extends Vendor_FirePHP {}