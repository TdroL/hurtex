<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 *  FirePHP Helper Wrapper
 */
class Fire extends FirePHP_Fire {


}
